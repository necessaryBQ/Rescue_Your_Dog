/*
 * I attest that the code in this file is entirely my own except for the starter
 * code provided with the assignment and the following exceptions:
 * <Enter all external resources and collaborations here. Note external code may
 * reduce your score but appropriate citation is required to avoid academic
 * integrity violations. Please see the Course Syllabus as well as the
 * university code of academic integrity:
 *  https://catalog.upenn.edu/pennbook/code-of-academic-integrity/ >
 * Signed,
 * Author: YOUR NAME HERE
 * Penn email: <YOUR-EMAIL-HERE@seas.upenn.edu>
 * Date: YYYY-MM-DD
 */

import java.util.List;

public class SplayTree<E extends Comparable<E>> {

    // Note - the client should not have access to this class. It has things like left/parent/right etc, which are
    // meant to be abstracted away from the client.
    private class Node {
        public E value;
        public Node left = null;
        public Node right = null;
        public Node parent = null;

        Node(E value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return "( " + value + " )";
        }
    }

    protected Node root = null;
    protected int size = 0;

    /**
     * Add the value to the tree if it does not exist. If it does exist, do not add any node. Do NOT splay. This is used
     * for testing.
     * @param val The value to add
     * @return True if the value is added, false otherwise.
     */
    public boolean addNoSplay(E val) {
        return false;
    }

    /**
     * Add the value to the tree if it does not exist. If it does exist, do not add any node. Splay as needed.
     * @param val The value to add
     * @return True if the value is added, null otherwise.
     */
    public boolean add(E val) {
        return false;
    }

    /**
     * Find a node and splay as needed.
     * @param val The value to find
     * @return The Node if it's value exists, null otherwise.
     */
    public boolean findNode(E val) {
        return false;
    }

    /**
     * Remove the node if it's value exists. If a node has 0 or 1 children, deletion is straightforward. Otherwise, we
     * swap the node to be deleted with the inorder predecessor, and now it will be reduced to the case of deletion of
     * 0 or 1 children. We splay as needed.
     * @param val The value to remove
     * @return True only if the value was removed from the BST
     */
    public boolean remove(E val) {
        return false;
    }

    /**
     * @return list of elements corresponding to inorder traversal.
     */
    public List<E> inOrder() {
        return null;
    }

    /**
     * @return list of elements corresponding to preorder traversal.
     */
    public List<E> preOrder() {
        return null;
    }

    /**
     * @return list of elements corresponding to postorder traversal.
     */
    public List<E> postOrder() {
        return null;
    }
}